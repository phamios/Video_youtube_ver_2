package vn.nad.aoeclips.screen.setting.controller;

import android.app.Activity;
import android.os.Bundle;

public class SettingActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
}
