package vn.nad.aoeclips.screen.category.controller;

import java.util.ArrayList;
import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.app.Activity;
import android.os.SystemClock;
import vn.admega.notification.NotificationPublisher;
import vn.nad.android.aoeclips.R;
import vn.nad.aoeclips.common.model.entity.Category;
import vn.nad.aoeclips.common.utils.Constants;
import vn.nad.aoeclips.common.utils.Logger;
import vn.nad.aoeclips.screen.category.controller.adapter.CategoryArrayAdapter;
import vn.nad.aoeclips.screen.category.controller.adapter.CategoryFragmentPagerAdapter;
import vn.nad.aoeclips.screen.category.controller.loader.DataCategoriesLoader;
import vn.nad.aoeclips.screen.setting.controller.SettingActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.LoaderManager;
import android.support.v4.app.LoaderManager.LoaderCallbacks;
import android.support.v4.content.Loader;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.support.v4.widget.DrawerLayout;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

@SuppressLint("NewApi")
public class MainActivity extends FragmentActivity implements Constants,
		LoaderCallbacks<ArrayList<Category>>, OnItemClickListener,
		OnPageChangeListener {
	private String TAG = MainActivity.class.getSimpleName();

	private DrawerLayout mDrawerLayout;
	private ListView mListCategory;
	private ActionBarDrawerToggle mDrawerToggle;
	private ArrayList<Category> simpleCategories = new ArrayList<Category>();

	private ProgressDialog mProgressDialog;

	// Navigation drawer title
	private CharSequence mTitleCategory;
	private CharSequence mTitle;

	// adapter Category
	private CategoryArrayAdapter mAdapterCategory;

	private ViewPager mViewPager;

	private CategoryFragmentPagerAdapter mAdapter;

	private InterstitialAd interstitial;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mTitle = mTitleCategory = getTitle();
		initData();

		startInterstitial();
		scheduleNotification(getNotification("News Clips has been updated, Click to watch it now !"), 1000000);
	}

	private void scheduleNotification(Notification notification, int delay) {

		Intent notificationIntent = new Intent(this,
				MainActivity.class);
		notificationIntent.putExtra(NotificationPublisher.NOTIFICATION_ID, 1);
		notificationIntent.putExtra(NotificationPublisher.NOTIFICATION,
				notification);
		PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0,
				notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);

		
		long futureInMillis = SystemClock.elapsedRealtime() + delay;
		AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, futureInMillis,
				pendingIntent);
	}

	private Notification getNotification(String content) {
		Notification.Builder builder = new Notification.Builder(this);
		builder.setContentTitle("New Movies - HOT");
		builder.setContentText(content);
		builder.setSmallIcon(R.drawable.ic_launcher);
		return builder.build();
	}

	public void startInterstitial() {
		interstitial = new InterstitialAd(MainActivity.this);
		interstitial.setAdUnitId("ca-app-pub-1214276490829950/6453857021");

		// AdView adView = (AdView) this.findViewById(R.id.adView);

		AdRequest adRequest = new AdRequest.Builder()
				.addTestDevice(AdRequest.DEVICE_ID_EMULATOR).addTestDevice("")
				.build();

		// adView.loadAd(adRequest);
		interstitial.loadAd(adRequest);
		interstitial.setAdListener(new AdListener() {
			public void onAdLoaded() {
				// Call displayInterstitial() function
				displayInterstitial();
			}
		});
	}

	public void displayInterstitial() {
		// If Ads are loaded, show Interstitial else show nothing.
		if (interstitial.isLoaded()) {
			interstitial.show();
		}
	}

	// findViewById
	public void findViewById() {
		mDrawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
		mListCategory = (ListView) findViewById(R.id.list_slidermenu);
		mViewPager = (ViewPager) findViewById(R.id.mViewPager);
		mAdapterCategory = new CategoryArrayAdapter(MainActivity.this,
				simpleCategories);
		mListCategory.setAdapter(mAdapterCategory);
	}

	private void initView() {
		Bundle bundle = new Bundle();
		bundle.putParcelableArrayList(
				CategoryFragmentPagerAdapter.ARGUMENT_CATEGORIES,
				simpleCategories);
		mAdapter = new CategoryFragmentPagerAdapter(
				getSupportFragmentManager(), bundle);

		mViewPager.setAdapter(mAdapter);
		mViewPager.setOffscreenPageLimit(0);
		mViewPager.setOnPageChangeListener(this);
	}

	// listener
	public void listener() {
		mListCategory.setOnItemClickListener(this);
	}

	public void initData() {
		initmProgressDialog();
		if (simpleCategories.size() == 0) {
			LoaderManager lm = getSupportLoaderManager();
			lm.destroyLoader(LOADER_ID_CATEGORIES);
			lm.initLoader(LOADER_ID_CATEGORIES, null, this);
		} else {
			findViewById();
			initView();
			listener();
			setActionBar();

		}
	}

	public void setActionBar() {
		// Enabling action bar app icon and behaving it as toggle button
		getActionBar().setDisplayHomeAsUpEnabled(true);
		getActionBar().setHomeButtonEnabled(true);
		getActionBar().setIcon(
				new ColorDrawable(getResources().getColor(
						android.R.color.transparent)));

		mDrawerToggle = new ActionBarDrawerToggle(MainActivity.this,
				mDrawerLayout, R.drawable.ic_drawer, R.string.select_category,
				R.string.select_category) {
			public void onDrawerClosed(android.view.View drawerView) {
				getActionBar().setTitle(mTitle);
				invalidateOptionsMenu();

			};

			public void onDrawerOpened(android.view.View drawerView) {
				getActionBar().setTitle(mTitleCategory);
				invalidateOptionsMenu();
			};
		};
		mDrawerLayout.setDrawerListener(mDrawerToggle);
	}

	/**
	 * Diplaying fragment view for selected nav drawer list item
	 * */
	private void displayView(int position) {
	}

	@Override
	public void setTitle(CharSequence title) {
		mTitle = title;
		getActionBar().setTitle(mTitle);
	}

	private void initmProgressDialog() {
		mProgressDialog = new ProgressDialog(this);
		mProgressDialog.setTitle(R.string.app_name);
		mProgressDialog.setMessage("Please wait...");
		mProgressDialog.setCancelable(false);
		mProgressDialog.setIndeterminate(true);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	/**
	 * On menu item selected
	 * */
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// toggle nav drawer on selecting action bar app icon/title
		if (mDrawerToggle.onOptionsItemSelected(item)) {
			return true;
		}
		// Handle action bar actions click
		switch (item.getItemId()) {
		case R.id.action_settings:
			// Selected settings menu item
			// launch Settings activity
			Intent intent = new Intent(MainActivity.this, SettingActivity.class);
			startActivity(intent);
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	/* *
	 * Called when invalidateOptionsMenu() is triggered
	 */
	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		// if nav drawer is opened, hide the action items
		// boolean drawerOpen = mDrawerLayout.isDrawerOpen(mDrawerLayout);
		// menu.findItem(R.id.action_settings).setVisible(!drawerOpen);
		return super.onPrepareOptionsMenu(menu);
	}

	/**
	 * loader
	 */
	@Override
	public Loader<ArrayList<Category>> onCreateLoader(int arg0, Bundle bundle) {
		mProgressDialog.show();
		return new DataCategoriesLoader(this);
	}

	@Override
	public void onLoadFinished(Loader<ArrayList<Category>> loader,
			ArrayList<Category> data) {
		mProgressDialog.dismiss();
		simpleCategories.clear();
		simpleCategories.addAll(data);
		Logger.out(TAG, "simpleCategories ; " + simpleCategories.size());
		// mAdapterCategory = new CategoryArrayAdapter(MainActivity.this,
		// simpleCategories);

		findViewById();
		initView();
		listener();
		setActionBar();

	}

	@Override
	public void onLoaderReset(Loader<ArrayList<Category>> arg0) {

	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position,
			long id) {
		mViewPager.setCurrentItem(position);
		mDrawerLayout.closeDrawers();
	}

	/**
	 * When using the ActionBarDrawerToggle, you must call it during
	 * onPostCreate() and onConfigurationChanged()...
	 */

	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		// Sync the toggle state after onRestoreInstanceState has occurred.
		// mDrawerToggle.syncState();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		// Pass any configuration change to the drawer toggls
		// mDrawerToggle.onConfigurationChanged(newConfig);
	}

	@Override
	public void onPageScrollStateChanged(int arg0) {

	}

	@Override
	public void onPageScrolled(int arg0, float arg1, int arg2) {

	}

	@Override
	public void onPageSelected(int position) {
		setTitle(simpleCategories.get(position).getCateName());
	}

	private long backPressedTime = 0;

	@Override
	public void onBackPressed() { // to prevent irritating accidental logouts
		long t = System.currentTimeMillis();
		if (t - backPressedTime > 2000) { // 2 secs
			backPressedTime = t;
			Toast.makeText(this, "Press back again to logout",
					Toast.LENGTH_SHORT).show();
		} else { // this guy is serious
			// clean up
			startInterstitial();
			super.onBackPressed(); // bye
		}
	}
}
