package vn.nad.aoeclips.screen.category.controller.adapter;
/**
 * @author ducna6417
 */
import java.util.ArrayList;

import vn.nad.android.aoeclips.R;
import vn.nad.aoeclips.common.model.entity.Article;
import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.presenter.target.ImageViewTarget;

public class ArticleListAdapter extends ArrayAdapter<Article> {
	private ArrayList<Article> listArticle = new ArrayList<Article>();
	private LayoutInflater mLayoutInflater;

	public ArticleListAdapter(Context context, ArrayList<Article> listArticle) {
		super(context, R.layout.item_list_video);
		this.mLayoutInflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		this.listArticle = listArticle;
	}

	@Override
	public int getCount() {
		return listArticle.size();
	}

	@Override
	public Article getItem(int position) {
		return listArticle.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder viewHolder = null;
		if (convertView == null) {
			convertView = mLayoutInflater.inflate(R.layout.item_list_video, parent, false);
			viewHolder = new ViewHolder();
			viewHolder.imageViewThumbVideo = (ImageView) convertView.findViewById(R.id.imageViewVideo);
			viewHolder.textViewTitleVideo = (TextView) convertView.findViewById(R.id.textViewTitleVideo);
			
			convertView.setTag(viewHolder);
		}else {
			viewHolder = (ViewHolder) convertView.getTag();
		}
		Article article = listArticle.get(position);
		viewHolder.textViewTitleVideo.setText(article.getName());
		
		Glide.load(article.getImage()).centerCrop().placeholder(R.drawable.icon_app).into(viewHolder.imageViewThumbVideo);

		return convertView;
	}

	class ViewHolder{
		private ImageView imageViewThumbVideo;
		private TextView textViewTitleVideo;
	}
	
	// solution produce Out Of Memory
	private class DownloadImageTarget extends ImageViewTarget{
		private ViewHolder holder;
		public DownloadImageTarget(ImageView imageView) {
			super(imageView);
		}
		public DownloadImageTarget(ViewHolder holder){
			super(holder.imageViewThumbVideo);
			holder = this.holder;
		}
		
		@Override
		public void onImageReady(Bitmap bitmap) {
	        // Size of image greater than 100kb, image width and image height 100px

	        if (bitmap!=null && bitmap.getHeight() > 100 && bitmap.getWidth() > 100) {
	            holder.imageViewThumbVideo.setImageBitmap(bitmap);
	        }else{
	        }
		}
	}
	
}
